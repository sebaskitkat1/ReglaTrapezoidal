package apptrapeciomultiple;

public class Expr {
    private final String e;
    private int p = 0;
    Expr(String e) { this.e = e; }
    double eval() { return suma(); }

    private double suma() {
        double v = mult();
        while (p < e.length() && (e.charAt(p)=='+' || e.charAt(p)=='-')) {
            char op = e.charAt(p++); double r = mult();
            v = op=='+' ? v+r : v-r;
        }
        return v;
    }
    private double mult() {
        double v = pot();
        while (p < e.length() && (e.charAt(p)=='*' || e.charAt(p)=='/')) {
            char op = e.charAt(p++); double r = pot();
            v = op=='*' ? v*r : v/r;
        }
        return v;
    }
    private double pot() {
        double base = unario();
        if (p < e.length() && e.charAt(p)=='^') {
            p++;
            return Math.pow(base, unario());
        }
        return base;
    }
    private double unario() {
        if (p < e.length() && e.charAt(p)=='-') { p++; return -prim(); }
        if (p < e.length() && e.charAt(p)=='+') { p++; return  prim(); }
        return prim();
    }
    private double prim() {
        if (p >= e.length()) throw new RuntimeException("Expresion incompleta");
        for (String fn : new String[]{
                "sen","sin","cos","tan","asin","acos","atan",
                "sqrt","ln","log","exp","abs","cosh","sinh","tanh"}) {
            if (e.startsWith(fn, p)) {
                p += fn.length();
                boolean par = p < e.length() && e.charAt(p)=='(';
                if (par) p++;
                double arg = suma();
                if (par && p < e.length() && e.charAt(p)==')') p++;
                return fn(fn, arg);
            }
        }
        if (e.charAt(p)=='(') {
            p++;
            double v = suma();
            if (p < e.length() && e.charAt(p)==')') p++;
            return v;
        }
        int ini = p;
        if (p < e.length() && e.charAt(p)=='-') p++;
        while (p < e.length() && (Character.isDigit(e.charAt(p))
            || e.charAt(p)=='.' || e.charAt(p)=='e' || e.charAt(p)=='E'
            || (e.charAt(p)=='-' && p>ini
                && (e.charAt(p-1)=='e'||e.charAt(p-1)=='E'))))
            p++;
        if (ini==p) throw new RuntimeException("Token inesperado en pos "+p);
        return Double.parseDouble(e.substring(ini, p));
    }
    private double fn(String n, double a) {
        switch (n) {
            case "sen": case "sin": return Math.sin(a);
            case "cos":  return Math.cos(a);
            case "tan":  return Math.tan(a);
            case "asin": return Math.asin(a);
            case "acos": return Math.acos(a);
            case "atan": return Math.atan(a);
            case "sqrt": return Math.sqrt(a);
            case "ln":   return Math.log(a);
            case "log":  return Math.log10(a);
            case "exp":  return Math.exp(a);
            case "abs":  return Math.abs(a);
            case "cosh": return Math.cosh(a);
            case "sinh": return Math.sinh(a);
            case "tanh": return Math.tanh(a);
            default: throw new RuntimeException("Funcion no reconocida: "+n);
        }
    }
}
