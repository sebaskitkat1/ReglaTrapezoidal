package apptrapeciomultiple;

public class TrapecioMultiple extends javax.swing.JFrame {
    private String   funcionActual   = "";
    private double   aActual         = 0;
    private double   bActual         = 0;
    private int      nActual         = 4;
    private double[] xPuntos;
    private double[] yPuntos;
    private boolean  calculado       = false;

    private void insertar(String s) {
        txtFuncion.setText(txtFuncion.getText() + s);
        txtFuncion.requestFocus();
    }
    
    private void calcular() {
        String fun = txtFuncion.getText().trim();
        if (fun.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Ingresa una función f(x).", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        double a, b;
        try {
            a = Double.parseDouble(txtA.getText().trim());
            b = Double.parseDouble(txtB.getText().trim());
        } catch (NumberFormatException ex) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Los límites a y b deben ser números.", "Error",
                javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (a >= b) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "El límite a debe ser menor que b.", "Error",
                javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        int n = (Integer) spnN.getValue();
        double h = (b - a) / n;

        // Calcular todos los puntos xi y f(xi)
        xPuntos = new double[n + 1];
        yPuntos = new double[n + 1];
        try {
            for (int i = 0; i <= n; i++) {
                xPuntos[i] = a + i * h;
                yPuntos[i] = evaluar(fun, xPuntos[i]);
            }
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Error en la función: " + ex.getMessage() +
                "\n\nUsa: * para multiplicar, ^ para potencia\n" +
                "sen(x), cos(x), ln(x), sqrt(x), e^x",
                "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Fórmula trapezoidal múltiple:
        // I ≈ (h/2) * [f(x0) + 2*f(x1) + 2*f(x2) + ... + 2*f(xn-1) + f(xn)]
        double sumaInterna = 0;
        for (int i = 1; i < n; i++) sumaInterna += yPuntos[i];
        double trapecio = (h / 2.0) * (yPuntos[0] + 2.0 * sumaInterna + yPuntos[n]);

        // Resultado analítico por Simpson compuesto n=10000
        double analitico;
        try { analitico = simpsonComp(fun, a, b, 10000); }
        catch (Exception ex) { analitico = trapecio; }

        // Error relativo
        double errRel = (Math.abs(analitico) > 1e-12)
            ? Math.abs(analitico - trapecio) / Math.abs(analitico) * 100.0
            : 0.0;

        // Guardar estado para la gráfica
        funcionActual = fun;
        aActual = a; bActual = b; nActual = n;
        calculado = true;

        // Mostrar resultados
        lblResultTrap.setText(String.format("%.10f", trapecio));
        lblResultAnalitico.setText(String.format("%.10f", analitico));
        lblError.setText(String.format("%.6f %%", errRel));
        lblError.setForeground(
            errRel < 1.0 ? new java.awt.Color(34,197,94)    
          : errRel < 5.0 ? new java.awt.Color(251,191,36)   
          :                new java.awt.Color(239,68,68));

        // Mostrar pasos
        txtPasos.setText(generarPasos(fun, a, b, n, h, sumaInterna, trapecio, analitico, errRel));
        txtPasos.setCaretPosition(0);
    }
    
    private String generarPasos(String fun, double a, double b, int n, double h,
                              double sumaInterna, double trap,
                              double analitico, double errRel) {
        StringBuilder sb = new StringBuilder();
        sb.append("══════════════════════════════════\n");
        sb.append("  TRAPEZOIDAL — SEGMENTOS MÚLTIPLES\n");
        sb.append("══════════════════════════════════\n\n");
        sb.append("Función : f(x) = ").append(fun).append("\n");
        sb.append(String.format("Límites : a = %g,  b = %g\n", a, b));
        sb.append(String.format("Segmentos: n = %d\n\n", n));

        sb.append("─── Paso 1: calcular h ───\n");
        sb.append("h = (b - a) / n\n");
        sb.append(String.format("h = (%.6f - %.6f) / %d\n", b, a, n));
        sb.append(String.format("h = %.10f\n\n", h));

        sb.append("─── Paso 2: puntos xi y f(xi) ───\n");
        for (int i = 0; i <= n; i++) {
            String coef = (i == 0 || i == n) ? "  1x" : "  2x";
            sb.append(String.format("%s f(x%d)=f(%.6f) = %.8f\n",
                coef, i, xPuntos[i], yPuntos[i]));
        }

        sb.append(String.format("\n─── Paso 3: sumatoria ───\n"));
        sb.append(String.format("f(x0)         = %.8f\n", yPuntos[0]));
        sb.append(String.format("2 * Sf(xi)    = %.8f  (i=1 a %d)\n", 2*sumaInterna, n-1));
        sb.append(String.format("f(x%d)        = %.8f\n", n, yPuntos[n]));
        double total = yPuntos[0] + 2*sumaInterna + yPuntos[n];
        sb.append(String.format("Total         = %.8f\n\n", total));

        sb.append("─── Paso 4: aplicar fórmula ───\n");
        sb.append("I = (h/2) * [f(x0) + 2*Sf(xi) + f(xn)]\n");
        sb.append(String.format("I = (%.8f/2) * %.8f\n", h, total));
        sb.append(String.format("I = %.10f\n\n", trap));

        sb.append("─── Resultado Analítico ───\n");
        sb.append("(Simpson compuesto, n=10000)\n");
        sb.append(String.format("  = %.10f\n\n", analitico));

        sb.append("─── Error Relativo ───\n");
        sb.append("|Analitico - Trapezoidal|\n");
        sb.append("------------------------  x 100\n");
        sb.append("       |Analitico|\n");
        sb.append(String.format("  = %.6f %%\n\n", errRel));

        if      (errRel < 1.0) sb.append("✓ Excelente: error < 1%");
        else if (errRel < 5.0) sb.append("⚠ Bueno: error < 5%\n  Aumenta n para mejorar.");
        else                   sb.append("✗ Error > 5%\n  Incrementa n para reducirlo.");
        return sb.toString();
    }
    
    private double evaluar(String expr, double x) {
        String e = expr.toLowerCase().trim().replace(" ", "");
        e = e.replace("pi", String.valueOf(Math.PI));
        e = e.replaceAll("(?<![a-z])e(?![a-z^])", String.valueOf(Math.E));
        e = e.replace("x", "(" + x + ")");
        return new Expr(e).eval();
    }
    
    private double simpsonComp(String fun, double a, double b, int n) {
        if (n % 2 != 0) n++;
        double h = (b - a) / n;
        double s = evaluar(fun, a) + evaluar(fun, b);
        for (int i = 1; i < n; i++)
            s += (i % 2 == 0 ? 2 : 4) * evaluar(fun, a + i * h);
        return s * h / 3.0;
    }
    
    public TrapecioMultiple() {
        initComponents();
        aplicarEstilos();
        this.setLocationRelativeTo(null);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtFuncion = new javax.swing.JTextField();
        txtA = new javax.swing.JTextField();
        txtB = new javax.swing.JTextField();
        spnN = new javax.swing.JSpinner();
        lblNValor = new javax.swing.JLabel();
        lblResultTrap = new javax.swing.JLabel();
        lblResultAnalitico = new javax.swing.JLabel();
        lblError = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtPasos = new javax.swing.JTextArea();
        btnSen = new javax.swing.JButton();
        btnCos = new javax.swing.JButton();
        btnTan = new javax.swing.JButton();
        btnRaiz = new javax.swing.JButton();
        btnLn = new javax.swing.JButton();
        btnLog = new javax.swing.JButton();
        btnPi = new javax.swing.JButton();
        btnE = new javax.swing.JButton();
        btnEx = new javax.swing.JButton();
        btnX2 = new javax.swing.JButton();
        btnX3 = new javax.swing.JButton();
        btnXn = new javax.swing.JButton();
        btnParA = new javax.swing.JButton();
        btnParC = new javax.swing.JButton();
        btnPot = new javax.swing.JButton();
        btnDiv = new javax.swing.JButton();
        btnMult = new javax.swing.JButton();
        btnRes = new javax.swing.JButton();
        btnSum = new javax.swing.JButton();
        btnBorrar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnCalcular = new javax.swing.JButton();
        btnMostrarGrafica = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        spnN.setModel(new javax.swing.SpinnerNumberModel(2, 2, 100, 1));
        spnN.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                spnNStateChanged(evt);
            }
        });

        lblNValor.setText("Valor N");

        lblResultTrap.setText("Resultado");

        lblResultAnalitico.setText("Resultado analitico");

        lblError.setText("Error");

        txtPasos.setColumns(20);
        txtPasos.setRows(5);
        jScrollPane1.setViewportView(txtPasos);

        btnSen.setText("sen()");
        btnSen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSenActionPerformed(evt);
            }
        });

        btnCos.setText("cos()");
        btnCos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCosActionPerformed(evt);
            }
        });

        btnTan.setText("tan()");
        btnTan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTanActionPerformed(evt);
            }
        });

        btnRaiz.setText("√");
        btnRaiz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRaizActionPerformed(evt);
            }
        });

        btnLn.setText("ln");
        btnLn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLnActionPerformed(evt);
            }
        });

        btnLog.setText("log");
        btnLog.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogActionPerformed(evt);
            }
        });

        btnPi.setText("π");
        btnPi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPiActionPerformed(evt);
            }
        });

        btnE.setText("e");
        btnE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEActionPerformed(evt);
            }
        });

        btnEx.setText("e^");
        btnEx.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExActionPerformed(evt);
            }
        });

        btnX2.setText("x^2");
        btnX2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnX2ActionPerformed(evt);
            }
        });

        btnX3.setText("x^3");
        btnX3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnX3ActionPerformed(evt);
            }
        });

        btnXn.setText("x^n");
        btnXn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXnActionPerformed(evt);
            }
        });

        btnParA.setText("(");
        btnParA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnParAActionPerformed(evt);
            }
        });

        btnParC.setText(")");
        btnParC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnParCActionPerformed(evt);
            }
        });

        btnPot.setText("^");
        btnPot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPotActionPerformed(evt);
            }
        });

        btnDiv.setText("/");
        btnDiv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDivActionPerformed(evt);
            }
        });

        btnMult.setText("*");
        btnMult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMultActionPerformed(evt);
            }
        });

        btnRes.setText("-");
        btnRes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResActionPerformed(evt);
            }
        });

        btnSum.setText("+");
        btnSum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSumActionPerformed(evt);
            }
        });

        btnBorrar.setText("Borrar");
        btnBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnCalcular.setText("Calcular");
        btnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularActionPerformed(evt);
            }
        });

        btnMostrarGrafica.setText("Crear grafica");
        btnMostrarGrafica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarGraficaActionPerformed(evt);
            }
        });

        jLabel1.setText("A");

        jLabel2.setText("B");

        jLabel3.setText("f(x)");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(spnN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblNValor, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblResultTrap, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblResultAnalitico)
                    .addComponent(lblError, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSen, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCos, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnTan, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRaiz, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnLn, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLog, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnPi, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnE, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEx, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnX2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnX3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnXn, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnParA)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnParC))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnBorrar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(btnPot)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnDiv)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnMult)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnRes)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSum))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)))
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtB, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtA, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtFuncion, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnMostrarGrafica, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 399, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFuncion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spnN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNValor, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addComponent(lblResultTrap, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblResultAnalitico, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblError, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSen)
                    .addComponent(btnCos)
                    .addComponent(btnTan)
                    .addComponent(btnRaiz))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLn)
                    .addComponent(btnLog)
                    .addComponent(btnPi)
                    .addComponent(btnE)
                    .addComponent(btnEx))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnX2)
                    .addComponent(btnX3)
                    .addComponent(btnXn)
                    .addComponent(btnParA)
                    .addComponent(btnParC))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPot)
                    .addComponent(btnDiv)
                    .addComponent(btnMult)
                    .addComponent(btnRes)
                    .addComponent(btnSum))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBorrar)
                    .addComponent(btnLimpiar)
                    .addComponent(btnCalcular))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnMostrarGrafica)
                .addGap(0, 14, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLnActionPerformed
        // TODO add your handling code here:
        insertar("ln(");
    }//GEN-LAST:event_btnLnActionPerformed

    private void btnLogActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogActionPerformed
        // TODO add your handling code here:
        insertar("log(");
    }//GEN-LAST:event_btnLogActionPerformed

    private void btnX2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnX2ActionPerformed
        // TODO add your handling code here:
        insertar("x^2");
    }//GEN-LAST:event_btnX2ActionPerformed

    private void btnX3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnX3ActionPerformed
        // TODO add your handling code here:
        insertar("x^3");
    }//GEN-LAST:event_btnX3ActionPerformed

    private void btnXnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXnActionPerformed
        // TODO add your handling code here:
        insertar("x^");
    }//GEN-LAST:event_btnXnActionPerformed

    private void btnParAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnParAActionPerformed
        // TODO add your handling code here:
        insertar("(");
    }//GEN-LAST:event_btnParAActionPerformed

    private void btnParCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnParCActionPerformed
        // TODO add your handling code here:
        insertar(")");
    }//GEN-LAST:event_btnParCActionPerformed

    private void btnPotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPotActionPerformed
        // TODO add your handling code here:
        insertar("^");
    }//GEN-LAST:event_btnPotActionPerformed

    private void btnDivActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDivActionPerformed
        // TODO add your handling code here:
        insertar("/");
    }//GEN-LAST:event_btnDivActionPerformed

    private void btnMultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMultActionPerformed
        // TODO add your handling code here:
        insertar("*");
    }//GEN-LAST:event_btnMultActionPerformed

    private void btnResActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResActionPerformed
        // TODO add your handling code here:
        insertar("-");
    }//GEN-LAST:event_btnResActionPerformed

    private void btnSumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSumActionPerformed
        // TODO add your handling code here:
        insertar("+");
    }//GEN-LAST:event_btnSumActionPerformed

    private void btnBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarActionPerformed
        // TODO add your handling code here:
         String t = txtFuncion.getText();
        if (!t.isEmpty()) txtFuncion.setText(t.substring(0, t.length() - 1));
    }//GEN-LAST:event_btnBorrarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // TODO add your handling code here:
        txtFuncion.setText("");
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularActionPerformed
        // TODO add your handling code here:
        calcular();
    }//GEN-LAST:event_btnCalcularActionPerformed

    private void btnSenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSenActionPerformed
        // TODO add your handling code here:
        insertar("sen(");
    }//GEN-LAST:event_btnSenActionPerformed

    private void btnCosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCosActionPerformed
        // TODO add your handling code here:
        insertar("cos(");
    }//GEN-LAST:event_btnCosActionPerformed

    private void btnTanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTanActionPerformed
        // TODO add your handling code here:
        insertar("tan(");
    }//GEN-LAST:event_btnTanActionPerformed

    private void btnRaizActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRaizActionPerformed
        // TODO add your handling code here:
        insertar("sqrt(");
    }//GEN-LAST:event_btnRaizActionPerformed

    private void btnPiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPiActionPerformed
        // TODO add your handling code here:
        insertar("3.14159265");
    }//GEN-LAST:event_btnPiActionPerformed

    private void btnEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEActionPerformed
        // TODO add your handling code here:
        insertar("2.71828182");
    }//GEN-LAST:event_btnEActionPerformed

    private void btnExActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExActionPerformed
        // TODO add your handling code here:
        insertar("e^x");
    }//GEN-LAST:event_btnExActionPerformed

    private void spnNStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_spnNStateChanged
        // TODO add your handling code here:
        lblNValor.setText(spnN.getValue().toString());
    }//GEN-LAST:event_spnNStateChanged

    private void btnMostrarGraficaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarGraficaActionPerformed
        // TODO add your handling code here:
        if (!calculado) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Primero calcula la integral.", "Aviso",
                javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        VentanaGrafica vg = new VentanaGrafica(
            funcionActual, aActual, bActual, nActual, xPuntos, yPuntos);
        vg.setVisible(true);
    }//GEN-LAST:event_btnMostrarGraficaActionPerformed

    private static final java.awt.Color C_FONDO  = new java.awt.Color(15,15,28);
    private static final java.awt.Color C_PANEL  = new java.awt.Color(24,24,42);
    private static final java.awt.Color C_BTN    = new java.awt.Color(30,45,70);
    private static final java.awt.Color C_TEXTO  = new java.awt.Color(220,220,235);
    private static final java.awt.Color C_TSEC   = new java.awt.Color(130,130,158);
    private static final java.awt.Color C_ACENTO = new java.awt.Color(99,102,241);
    private static final java.awt.Color C_GBKG   = new java.awt.Color(10,10,20);

    private void aplicarEstilos() {

        // Fondo general de la ventana
        getContentPane().setBackground(C_FONDO);

        // Todos los paneles (JPanels)
        for (java.awt.Component c : getContentPane().getComponents()) {
            colorearComponente(c);
        }

        // Campo de función
        txtFuncion.setBackground(C_GBKG);
        txtFuncion.setForeground(C_TEXTO);
        txtFuncion.setCaretColor(C_TEXTO);
        txtFuncion.setBorder(javax.swing.BorderFactory.createLineBorder(C_ACENTO, 1));

        // Límites a y b
        txtA.setBackground(C_GBKG);
        txtA.setForeground(C_TEXTO);
        txtA.setCaretColor(C_TEXTO);
        txtA.setBorder(javax.swing.BorderFactory.createLineBorder(C_ACENTO, 1));

        txtB.setBackground(C_GBKG);
        txtB.setForeground(C_TEXTO);
        txtB.setCaretColor(C_TEXTO);
        txtB.setBorder(javax.swing.BorderFactory.createLineBorder(C_ACENTO, 1));

        // Spinner n
        spnN.setBackground(C_GBKG);
        spnN.setForeground(C_TEXTO);
        ((javax.swing.JSpinner.DefaultEditor) spnN.getEditor())
            .getTextField().setBackground(C_GBKG);
        ((javax.swing.JSpinner.DefaultEditor) spnN.getEditor())
            .getTextField().setForeground(C_TEXTO);

        // Labels de resultado
        for (javax.swing.JLabel lbl : new javax.swing.JLabel[]{
                lblResultTrap, lblResultAnalitico, lblError, lblNValor}) {
            lbl.setForeground(C_TEXTO);
        }

        // Área de pasos
        txtPasos.setBackground(C_GBKG);
        txtPasos.setForeground(C_TEXTO);
        txtPasos.setCaretColor(C_TEXTO);

        // Botones de funciones
        for (javax.swing.JButton b : new javax.swing.JButton[]{
                btnSen, btnCos, btnTan, btnRaiz, btnLn, btnLog,
                btnPi, btnE, btnEx, btnX2, btnX3, btnXn,
                btnParA, btnParC, btnPot, btnDiv, btnMult, btnRes, btnSum,
                btnBorrar, btnLimpiar}) {
            b.setBackground(C_BTN);
            b.setForeground(C_TEXTO);
            b.setFocusPainted(false);
            b.setBorder(javax.swing.BorderFactory.createLineBorder(
                new java.awt.Color(60,60,100), 1));
        }

        // Botón calcular (más destacado)
        btnCalcular.setBackground(C_BTN);
        btnCalcular.setForeground(C_TEXTO);
        btnCalcular.setFocusPainted(false);
        btnCalcular.setFont(btnCalcular.getFont().deriveFont(java.awt.Font.PLAIN, 12f));
        btnCalcular.setBorder(javax.swing.BorderFactory.createLineBorder(
            new java.awt.Color(60,60,100), 1));

        // Botón gráfica
        btnMostrarGrafica.setBackground(new java.awt.Color(40,120,80));
        btnMostrarGrafica.setForeground(java.awt.Color.WHITE);
        btnMostrarGrafica.setFocusPainted(false);
        
        //Spinner N
        spnN.setBackground(C_BTN);
        spnN.setForeground(C_TEXTO);
        spnN.setBorder(javax.swing.BorderFactory.createLineBorder(
            new java.awt.Color(60,60,100), 1));
        ((javax.swing.JSpinner.DefaultEditor) spnN.getEditor())
            .getTextField().setBackground(C_BTN);
        ((javax.swing.JSpinner.DefaultEditor) spnN.getEditor())
            .getTextField().setForeground(C_TEXTO);
        ((javax.swing.JSpinner.DefaultEditor) spnN.getEditor())
            .getTextField().setCaretColor(C_TEXTO);
        ((javax.swing.JSpinner.DefaultEditor) spnN.getEditor())
            .getTextField().setBorder(javax.swing.BorderFactory.createEmptyBorder());

    }

    // ── Colorea recursivamente paneles y labels ───────────────────────────
    private void colorearComponente(java.awt.Component c) {
        if (c instanceof javax.swing.JPanel) {
            c.setBackground(C_PANEL);
            for (java.awt.Component hijo : ((javax.swing.JPanel) c).getComponents()) {
                colorearComponente(hijo);
            }
        }
        if (c instanceof javax.swing.JLabel) {
            c.setForeground(C_TSEC);
        }
        if (c instanceof javax.swing.JScrollPane) {
            c.setBackground(C_GBKG);
            ((javax.swing.JScrollPane) c).getViewport().setBackground(C_GBKG);
        }
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TrapecioMultiple.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TrapecioMultiple.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TrapecioMultiple.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TrapecioMultiple.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TrapecioMultiple().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnCalcular;
    private javax.swing.JButton btnCos;
    private javax.swing.JButton btnDiv;
    private javax.swing.JButton btnE;
    private javax.swing.JButton btnEx;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnLn;
    private javax.swing.JButton btnLog;
    private javax.swing.JButton btnMostrarGrafica;
    private javax.swing.JButton btnMult;
    private javax.swing.JButton btnParA;
    private javax.swing.JButton btnParC;
    private javax.swing.JButton btnPi;
    private javax.swing.JButton btnPot;
    private javax.swing.JButton btnRaiz;
    private javax.swing.JButton btnRes;
    private javax.swing.JButton btnSen;
    private javax.swing.JButton btnSum;
    private javax.swing.JButton btnTan;
    private javax.swing.JButton btnX2;
    private javax.swing.JButton btnX3;
    private javax.swing.JButton btnXn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblError;
    private javax.swing.JLabel lblNValor;
    private javax.swing.JLabel lblResultAnalitico;
    private javax.swing.JLabel lblResultTrap;
    private javax.swing.JSpinner spnN;
    private javax.swing.JTextField txtA;
    private javax.swing.JTextField txtB;
    private javax.swing.JTextField txtFuncion;
    private javax.swing.JTextArea txtPasos;
    // End of variables declaration//GEN-END:variables
}
