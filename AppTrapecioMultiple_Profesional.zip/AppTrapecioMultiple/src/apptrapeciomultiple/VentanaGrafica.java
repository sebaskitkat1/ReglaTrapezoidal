/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package apptrapeciomultiple;

/**
 *
 * @author paqui
 */
public class VentanaGrafica extends javax.swing.JFrame {

    /**
     * Creates new form VentanaGrafica
     */
    private String   funcion;
    private double   a, b;
    private int      n;
    private double[] xPuntos, yPuntos;
    private PanelGrafica panel;
    
    private static final java.awt.Color C_GBKG    = new java.awt.Color(10,10,20);
    private static final java.awt.Color C_TSEC    = new java.awt.Color(130,130,158);
    private static final java.awt.Color C_FUNCION = new java.awt.Color(99,202,255);
    private static final java.awt.Color C_TRAPF   = new java.awt.Color(99,102,241,55);
    private static final java.awt.Color C_TRAPB   = new java.awt.Color(99,102,241,210);
    private static final java.awt.Color C_PUNTO   = new java.awt.Color(168,85,247);
    private static final java.awt.Color C_ACENTO  = new java.awt.Color(99,102,241);
    private static final java.awt.Color C_ACENTO2 = new java.awt.Color(168,85,247);
    
    public VentanaGrafica() {
        initComponents();
    }
    
    public VentanaGrafica(String funcion, double a, double b, int n,
                      double[] xPts, double[] yPts) {
        initComponents();
        setTitle("Gráfica — Trapezoidal Múltiple");
        setSize(750, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        this.funcion = funcion;
        this.a = a; this.b = b; this.n = n;
        this.xPuntos = xPts; this.yPuntos = yPts;

        panel = new PanelGrafica();
        getContentPane().setLayout(new java.awt.BorderLayout());
        getContentPane().add(panel, java.awt.BorderLayout.CENTER);
    }
    
     private double evaluar(String expr, double x) {
        String e = expr.toLowerCase().trim().replace(" ", "");
        e = e.replace("pi", String.valueOf(Math.PI));
        e = e.replaceAll("(?<![a-z])e(?![a-z^])", String.valueOf(Math.E));
        e = e.replace("x", "(" + x + ")");
        return new Expr(e).eval();
    }
     
    private class PanelGrafica extends javax.swing.JPanel {
        @Override
        protected void paintComponent(java.awt.Graphics raw) {
            super.paintComponent(raw);
            java.awt.Graphics2D g = (java.awt.Graphics2D) raw;
            g.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING,
                java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(java.awt.RenderingHints.KEY_TEXT_ANTIALIASING,
                java.awt.RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int W=getWidth(), H=getHeight();
            int mL=60, mR=18, mT=20, mB=42;
            int gW=W-mL-mR, gH=H-mT-mB;

            g.setColor(C_GBKG);
            g.fillRect(0, 0, W, H);

            if (funcion.isEmpty()) {
                g.setColor(C_TSEC);
                g.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
                String msg = "Presiona CALCULAR INTEGRAL para ver la grafica";
                java.awt.FontMetrics fm = g.getFontMetrics();
                g.drawString(msg, (W-fm.stringWidth(msg))/2, H/2);
                return;
            }

            // Rango x con margen
            double marg = (b-a)*0.25;
            double xMin=a-marg, xMax=b+marg;

            // Evaluar curva
            int NP = 400;
            double[] cxs=new double[NP], cys=new double[NP];
            double yMin=Double.MAX_VALUE, yMax=-Double.MAX_VALUE;
            for (int i=0; i<NP; i++) {
                cxs[i] = xMin+(xMax-xMin)*i/(NP-1);
                try {
                    cys[i] = evaluar(funcion, cxs[i]);
                    if (Double.isFinite(cys[i])) {
                        if (cys[i]<yMin) yMin=cys[i];
                        if (cys[i]>yMax) yMax=cys[i];
                    }
                } catch(Exception ex) { cys[i]=Double.NaN; }
            }
            for (double y : yPuntos) {
                if (y<yMin) yMin=y; if (y>yMax) yMax=y;
            }
            if (!Double.isFinite(yMin)||!Double.isFinite(yMax)) return;
            double yr=yMax-yMin;
            if (yr<1e-10) { yr=2; yMin-=1; yMax+=1; }
            yMin-=yr*0.12; yMax+=yr*0.12;

            // Capturas finales para uso en lambdas
            final double fxMin=xMin,fxMax=xMax,fyMin=yMin,fyMax=yMax;
            final int fmL=mL,fmT=mT,fgW=gW,fgH=gH;

            // Grilla
            g.setColor(new java.awt.Color(32,32,55));
            g.setStroke(new java.awt.BasicStroke(0.5f));
            for (int i=0; i<=8; i++) {
                int xp=(int)(mL+gW*i/8.0), yp=(int)(mT+gH*i/8.0);
                g.drawLine(xp,mT,xp,mT+gH);
                g.drawLine(mL,yp,mL+gW,yp);
            }
            // Eje y=0
            if (yMin<0 && yMax>0) {
                int y0=(int)(mT+gH-(0-fyMin)/(fyMax-fyMin)*fgH);
                g.setColor(new java.awt.Color(70,70,105));
                g.drawLine(mL,y0,mL+gW,y0);
            }
            // Marco
            g.setColor(new java.awt.Color(60,60,90));
            g.setStroke(new java.awt.BasicStroke(1f));
            g.drawRect(mL,mT,gW,gH);

            // Trapecios (uno por cada segmento)
            int y0b = (int)(mT+gH-(Math.max(fyMin,0)-fyMin)/(fyMax-fyMin)*fgH);
            if (fyMin>0) y0b=(int)(mT+gH);

            g.setStroke(new java.awt.BasicStroke(1.2f));
            for (int i=0; i<n; i++) {
                int x1=(int)(fmL+(xPuntos[i  ]-fxMin)/(fxMax-fxMin)*fgW);
                int x2=(int)(fmL+(xPuntos[i+1]-fxMin)/(fxMax-fxMin)*fgW);
                int y1=(int)(fmT+fgH-(yPuntos[i  ]-fyMin)/(fyMax-fyMin)*fgH);
                int y2=(int)(fmT+fgH-(yPuntos[i+1]-fyMin)/(fyMax-fyMin)*fgH);
                int[] xs={x1,x2,x2,x1};
                int[] ys={y0b,y0b,y2,y1};
                java.awt.Color fill = (i%2==0)
                    ? C_TRAPF
                    : new java.awt.Color(168,85,247,45);
                g.setColor(fill);
                g.fillPolygon(xs,ys,4);
                g.setColor(C_TRAPB);
                g.drawPolygon(xs,ys,4);
            }

            // Curva f(x)
            java.awt.Shape clip = g.getClip();
            g.setClip(mL,mT,gW,gH);
            g.setStroke(new java.awt.BasicStroke(2.3f,
                java.awt.BasicStroke.CAP_ROUND,java.awt.BasicStroke.JOIN_ROUND));
            g.setColor(C_FUNCION);
            java.awt.geom.Path2D.Double curva = new java.awt.geom.Path2D.Double();
            boolean first=true;
            for (int i=0; i<NP; i++) {
                if (!Double.isFinite(cys[i])) { first=true; continue; }
                double px=fmL+(cxs[i]-fxMin)/(fxMax-fxMin)*fgW;
                double py=fmT+fgH-(cys[i]-fyMin)/(fyMax-fyMin)*fgH;
                if (first) { curva.moveTo(px,py); first=false; }
                else curva.lineTo(px,py);
            }
            g.draw(curva);
            g.setClip(clip);

            // Líneas verticales en a y b
            int xa=(int)(fmL+(a-fxMin)/(fxMax-fxMin)*fgW);
            int xb=(int)(fmL+(b-fxMin)/(fxMax-fxMin)*fgW);
            g.setColor(new java.awt.Color(99,102,241,150));
            g.setStroke(new java.awt.BasicStroke(1.3f,java.awt.BasicStroke.CAP_BUTT,
                java.awt.BasicStroke.JOIN_MITER,10f,new float[]{5,3},0));
            g.drawLine(xa,mT,xa,mT+gH);
            g.drawLine(xb,mT,xb,mT+gH);

            // Puntos xi
            int r=5;
            g.setStroke(new java.awt.BasicStroke(1.8f));
            for (int i=0; i<=n; i++) {
                int px=(int)(fmL+(xPuntos[i]-fxMin)/(fxMax-fxMin)*fgW);
                int py=(int)(fmT+fgH-(yPuntos[i]-fyMin)/(fyMax-fyMin)*fgH);
                g.setColor(C_PUNTO);
                g.fillOval(px-r,py-r,r*2,r*2);
                g.setColor(java.awt.Color.WHITE);
                g.drawOval(px-r,py-r,r*2,r*2);
            }

            // Etiquetas de ejes
            g.setFont(new java.awt.Font("Segoe UI",java.awt.Font.PLAIN,10));
            g.setColor(C_TSEC);
            for (int i=0; i<=5; i++) {
                double vy=fyMin+(fyMax-fyMin)*i/5.0;
                double vx=fxMin+(fxMax-fxMin)*i/5.0;
                int yp=(int)(mT+gH-(vy-fyMin)/(fyMax-fyMin)*gH);
                int xp=(int)(mL+(vx-fxMin)/(fxMax-fxMin)*gW);
                g.drawString(String.format("%.2f",vy), 2, yp+4);
                g.drawString(String.format("%.2f",vx), xp-14, mT+gH+14);
            }
            // Etiquetas a, b y n
            g.setColor(C_ACENTO);
            g.setFont(new java.awt.Font("Segoe UI",java.awt.Font.BOLD,11));
            g.drawString("a="+String.format("%.2f",a), xa-20, mT+gH+28);
            g.drawString("b="+String.format("%.2f",b), xb-8,  mT+gH+28);
            g.setColor(C_ACENTO2);
            g.setFont(new java.awt.Font("Segoe UI",java.awt.Font.BOLD,12));
            g.drawString("n="+n, mL+8, mT+16);
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaGrafica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaGrafica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaGrafica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaGrafica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaGrafica().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
